
import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def handler(event, context):
    message = os.environ.get('MESSAGE', 'Error')
    dsn = os.environ.get('SENTRY_DSN', 'Error')
    logger.info(f'Receive new sns notification send message: {message} to dsn: {dsn}')
    ...
